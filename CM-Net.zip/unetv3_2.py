import os.path
import warnings

import torch
from torch import nn
from pvtv2 import *
import torch.nn.functional as F
from Da_block import *
from dysample import *
import torch

torch.autograd.set_detect_anomaly(True)



# 定义通道注意力模块
class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))  # 平均池化分支
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))  # 最大池化分支
        out = avg_out + max_out  # 融合两个分支
        return self.sigmoid(out)  # 使用Sigmoid激活


# 定义空间注意力模块
class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'# 确保核尺寸为3或7
        padding = 3 if kernel_size == 7 else 1 # 根据核尺寸设置填充

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)  # 计算平均值
        max_out, _ = torch.max(x, dim=1, keepdim=True)  # 计算最大值
        x = torch.cat([avg_out, max_out], dim=1)  # 合并平均值和最大值
        x = self.conv1(x)  # 卷积操作
        return self.sigmoid(x)  # 使用Sigmoid激活

# 定义基础卷积模块
class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()

        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=False)

    def forward(self, x):
        x = self.conv(x)  # 卷积操作
        x = self.bn(x)  # 批量归一化
        return x

# 定义编码器模块
class Encoder(nn.Module):
    def __init__(self, pretrained_path=None, dim=16, num_heads=8):
        super(Encoder, self).__init__()
        self.backbone = pvt_v2_b2()
        if pretrained_path is None:
            warnings.warn('please provide the pretrained pvt model. Not using pretrained model.')
            # 提示没有提供预训练模型
        elif not os.path.isfile(pretrained_path):
            warnings.warn(f'path: {pretrained_path} does not exists. Not using pretrained model.')
            # 提示路径不存在
        else:
            print(f"using pretrained file: {pretrained_path}")
            save_model = torch.load(pretrained_path)  # 加载预训练模型
            model_dict = self.backbone.state_dict() # 获取当前模型的状态字典
            state_dict = {k: v for k, v in save_model.items() if k in model_dict.keys()}# 匹配预训练模型的参数
            model_dict.update(state_dict)# 更新当前模型的参数

            self.backbone.load_state_dict(model_dict) # 加载更新后的状态字典

    def forward(self, x):
        f1, f2, f3, f4 = self.backbone(x)  # (x: 3, 352, 352) 获取四个特征图
        return f1, f2, f3, f4

# 定义SDI模块
class SDI(nn.Module):
    def __init__(self, channel):
        super().__init__()

        self.convs = nn.ModuleList(  # 定义4个卷积层
            [nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1) for _ in range(4)])

    def forward(self, xs, anchor):
        ans = torch.ones_like(anchor)  # 初始化输出特征图
        target_size = anchor.shape[-1] # 获取目标特征图的大小

        for i, x in enumerate(xs):
            if x.shape[-1] > target_size:
                x = F.adaptive_avg_pool2d(x, (target_size, target_size))  # 下采样
            elif x.shape[-1] < target_size:
                x = F.interpolate(x, size=(target_size, target_size),    # 上采样
                                      mode='bilinear', align_corners=True)

            ans = ans * self.convs[i](x)  # 将卷积结果与当前输出特征图相乘

        return ans

# 定义UNetV2模型
class UNetV2(nn.Module):
    """
    使用空间注意力和通道注意力
    """
    def __init__(self, channel=32, n_classes=1, deep_supervision=True, pretrained_path=False):
        super().__init__()
        self.deep_supervision = deep_supervision
        self.encoder = Encoder(pretrained_path)
        
        '''
        # 添加DilateAttention和MultiDilatelocalAttention模块
        self.Dilate_Attention_1 = MultiDilatelocalAttention(dim=64, num_heads=8)
        self.Dilate_Attention_2 = MultiDilatelocalAttention(dim=32, num_heads=8)
        self.Dilate_Attention_3 = MultiDilatelocalAttention(dim=16, num_heads=8)
        self.Dilate_Attention_4 = MultiDilatelocalAttention(dim=8, num_heads=8)
        '''
        # 定义da
        self.da_1 = DANetHead(64, 64)
        self.da_2 = DANetHead(128, 128)
        self.da_3 = DANetHead(320, 320)
        self.da_4 = DANetHead(512, 512)

        '''
        # 定义各层的通道注意力和空间注意力
        self.ca_1 = ChannelAttention(64)
        self.sa_1 = SpatialAttention()

        self.ca_2 = ChannelAttention(128)
        self.sa_2 = SpatialAttention()

        self.ca_3 = ChannelAttention(320)
        self.sa_3 = SpatialAttention()

        self.ca_4 = ChannelAttention(512)
        self.sa_4 = SpatialAttention()
        '''

        # 定义各层的卷积变换
        self.Translayer_1 = BasicConv2d(64, channel, 1)
        self.Translayer_2 = BasicConv2d(128, channel, 1)
        self.Translayer_3 = BasicConv2d(320, channel, 1)
        self.Translayer_4 = BasicConv2d(512, channel, 1)
        
        

        # 定义SDI模块
        self.sdi_1 = SDI(channel)
        self.sdi_2 = SDI(channel)
        self.sdi_3 = SDI(channel)
        self.sdi_4 = SDI(channel)
        
        # 定义 DySample 实例用于上采样
        self.dysample1 = DySample(in_channels=channel, scale=2, style='lp')
        self.dysample2 = DySample(in_channels=channel, scale=2, style='lp')
        self.dysample3 = DySample(in_channels=channel, scale=2, style='lp')
        self.dysample4 = DySample(in_channels=channel, scale=2, style='lp')
        


        # 定义输出层
        self.seg_outs = nn.ModuleList([
            nn.Conv2d(channel, n_classes, 1, 1) for _ in range(4)])

        # 定义反卷积层(上采样)
        self.deconv2 = nn.ConvTranspose2d(channel, channel, kernel_size=4, stride=2, padding=1,
                                          bias=False)
        self.deconv3 = nn.ConvTranspose2d(channel, channel, kernel_size=4, stride=2,
                                          padding=1, bias=False)
        self.deconv4 = nn.ConvTranspose2d(channel, channel, kernel_size=4, stride=2,
                                          padding=1, bias=False)
        self.deconv5 = nn.ConvTranspose2d(channel, channel, kernel_size=4, stride=2,
                                          padding=1, bias=False)

    def forward(self, x):
        seg_outs = []
        f1, f2, f3, f4 = self.encoder(x)

        '''
        f1 = self.ca_1(f1) * f1
        f1 = self.sa_1(f1) * f1
        f1 = self.Translayer_1(f1)

        f2 = self.ca_2(f2) * f2
        f2 = self.sa_2(f2) * f2
        f2 = self.Translayer_2(f2)

        f3 = self.ca_3(f3) * f3
        f3 = self.sa_3(f3) * f3
        f3 = self.Translayer_3(f3)

        f4 = self.ca_4(f4) * f4
        f4 = self.sa_4(f4) * f4
        f4 = self.Translayer_4(f4)
        '''
        f1 = self.da_1(f1) * f1
        f2 = self.da_2(f2) * f2
        f3 = self.da_3(f3) * f3
        f4 = self.da_4(f4) * f4
    
        
        f1 = self.Translayer_1(f1)
        f2 = self.Translayer_2(f2)
        f3 = self.Translayer_3(f3)
        f4 = self.Translayer_4(f4)
      
        

        
        # 使用SDI模块融合特征
        f41 = self.sdi_4([f1, f2, f3, f4], f4)
        f31 = self.sdi_3([f1, f2, f3, f4], f3)
        f21 = self.sdi_2([f1, f2, f3, f4], f2)
        f11 = self.sdi_1([f1, f2, f3, f4], f1)
 
        '''
        # 生成分割输出
        # seg_outs.append(self.seg_outs[0](f41).clone())

        # 反卷积操作
        y = self.deconv2(f41) + f31
        # seg_outs.append(self.seg_outs[1](y).clone())

        y = self.deconv3(y) + f21
        # seg_outs.append(self.seg_outs[2](y).clone())

        # y = self.deconv4(y).clone() + f11
        # seg_outs.append(self.seg_outs[3](y))
        '''
        
        # 使用 DySample 实例进行上采样
        y = self.dysample1(f41) + f31  # 替换 self.deconv2(f41) + f31
        y = self.dysample2(y) + f21   # 替换 self.deconv3(y) + f21


        '''
        # 上采样到原始输入的尺寸
        for i, o in enumerate(seg_outs):
            seg_outs[i] = F.interpolate(o, scale_factor=4, mode='bilinear')

        # 根据是否使用深度监督返回结果
        if self.deep_supervision:
            return seg_outs[::-1]  # 返回各层的输出
        else:
            return seg_outs[-1]  # 返回最终输出
        '''


          # 如果使用深度监督
        if self.deep_supervision:
            out1 = self.seg_outs[0](y).clone()

        y = self.dysample3(y) + f11   # 替换 self.deconv4(y)
        out2 = self.seg_outs[1](y).clone()


        
        if self.deep_supervision:
            return F.interpolate(out1, scale_factor=8, mode='bilinear'), \
                F.interpolate(out2, scale_factor=4, mode='bilinear')
        else:
            return F.interpolate(out2, scale_factor=4, mode='bilinear')


if __name__ == "__main__":
    pretrained_path = "/code/U-Net_v2/model_pth/best_epoch_97.pth"
    model = UNetV2(n_classes=1, deep_supervision=True, pretrained_path=pretrained_path)
    x = torch.rand((2, 3, 256, 256))
    ys = model(x)
    for y in ys:
        print(y.shape)
